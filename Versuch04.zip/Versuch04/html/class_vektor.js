var class_vektor =
[
    [ "Vektor", "class_vektor.html#a744b4980d331af082c08890ff2e4a857", null ],
    [ "~Vektor", "class_vektor.html#a66e8e932c4e2df23b5a1d4c4764ce9d2", null ],
    [ "ausgabe", "class_vektor.html#aa3c41759f0a472327a8970878234675a", null ],
    [ "laenge", "class_vektor.html#a7e0b4c5110595bc81c8824e735af99aa", null ],
    [ "rotiereUmZ", "class_vektor.html#a6c2a59e620a7bbaa38900ef32b5471e7", null ],
    [ "skalarProd", "class_vektor.html#a5c2887f0690d9ffd1bba0a16bd8cc477", null ],
    [ "sub", "class_vektor.html#a9e095d5d627ad26c7c2d6f227567e731", null ],
    [ "winkel", "class_vektor.html#a66d1f47d9c7f6d985f39e9f34fb3f0d5", null ]
];