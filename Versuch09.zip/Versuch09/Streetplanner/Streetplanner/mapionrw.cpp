///////////////////////////////////////////////////////////////////////////////
// Praktikum Informatik 1 MMXXVI
// Versuch 9
//////////////////////////////////////////////////////////////////////////////

#include "mapionrw.h"

/**
 * @brief Creates the hardcoded NRW map provider.
 */
MapIoNrw::MapIoNrw()
{
}

/**
 * @brief Destroys the hardcoded NRW map provider.
 */
MapIoNrw::~MapIoNrw()
{
}

/**
 * @brief Fills the target map with a small predefined NRW example.
 */
void MapIoNrw::fillMap(AbstractMap &map)
{
    // Create a very small fixed example map used for testing and demonstrations.
    City* aachen = new City("Aachen", -100, 100);
    City* bonn = new City("Bonn", 0, 200);
    City* koeln = new City("Köln", 0, 0);
    City* duesseldorf = new City("Düsseldorf", 50, -100);

    Street* aachenKoeln = new Street(aachen, koeln);
    Street* bonnKoeln = new Street(bonn, koeln);
    Street* ddorfKoeln = new Street(duesseldorf, koeln);

    // Add all cities first so the later street insertion succeeds.
    map.addCity(aachen);
    map.addCity(bonn);
    map.addCity(koeln);
    map.addCity(duesseldorf);

    map.addStreet(aachenKoeln);
    map.addStreet(bonnKoeln);
    map.addStreet(ddorfKoeln);
}
